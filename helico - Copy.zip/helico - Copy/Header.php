<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Laat uw vloeistoffen laten afvullen door Helico Packaging! Wij bieden alle denkbare sluitingen en overdozen naar wens. Eventuele distributie? Lees meer op onze website!" />
    <title>Helico</title>   

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <link href="http://localhost/localwp/wp-content/themes/helico%20-%20copy/style.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
    <!-- Custom styles for this template -->
    <!--<link href="src/carousel.css" rel="stylesheet"> -->
  </head>


  <body>
    

    <!-- navbar -->
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark nav nav-pills nav-fill">
    <img src="http://localhost/localwp/wp-content/uploads/2022/08/logo.png">
      <div class="container-fluid">
          
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <ul class="navbar-nav me-auto mx-auto mb-2 mb-md-0"  >
              <li class="nav-item nav-my-item">
                <a class="nav-item nav-link" aria-current="page" href="#">Home</a>
              </li>
              <li class="nav-item nav-my-item">
                <a class="nav-item nav-link" href="#overons">Over ons</a>
              </li>
              <li class="nav-item nav-my-item">
                <a class="nav-item nav-link " href="#contact">Contact</a>
              </li>
              <li class="nav-item nav-my-item">
                <a class="nav-item nav-link" href="helico.html">Helico Packaging</a>
              </li>
            </ul>
          </div>
    </div>
    </nav>
    <!-- end navbar -->

    <!-- Background image -->
   <!-- Full Page Image Header with Vertically Centered Content -->
<header class="masthead newheaderhelico" >
    <div class="container h-100">
      <div class="row h-100 align-items-center">
        <div class="col-12 text-center myheader">
          <h1 class="headertextcolor">Helico</h1>
          <!--<p class="lead">Voor al uw verpak- en ompak benodigdheden!</p>-->
        </div>
      </div>
    </div>
    <div id="overons"></div> 
  </header>