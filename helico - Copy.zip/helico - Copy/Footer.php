  
    

  <!-- Footer -->
  <footer class="text-center text-lg-start bg-light text-muted" id="contact">
    <!-- Section: Social media -->
    <section
      class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom"
    >
    <!-- Section: Links  -->
    <section class="">
      <div class="container text-center text-md-start mt-5">
        <!-- Grid row -->
        <div class="row mt-3">
          <!-- Grid column -->
          <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
            <!-- Content -->
            <h6 class="text-uppercase fw-bold mb-4">
                <p><i class="fas fa-home me-3"></i> Helico B.V.</p>
            </h6>
            <p>
              Heeft u interesse in het laten ompakken en-of verpakken van uw product? Neem dan contact met ons op!
            </p>

            <p class="float-end"><a href="#">Back to top</a></p>
          </div>
          <!-- Grid column -->
  
          
  
          <!-- Grid column -->
          <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4" >
            <!-- Links -->
            <h6 class="text-uppercase fw-bold mb-4">
              Contact
            </h6>
            
            <p><i class="fas fa-home me-3"></i>Hoogschaijksestraat 31, 5374 EC Schaijk</p>
                

            <p>
              <i class="fas fa-envelope me-3"></i>
              info@helico.biz
            </p>
            <p><i class="fas fa-phone me-3"></i>Telefoon: +31 (0) 486-464274</p>
            <p><i class="fas fa-print me-3"></i>Fax: +31 (0) 485-464509</p>
            <p><i class="fas fa-print me-3">Kvk inschrijfnummer: 51380609</p>
          </div>

          <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4" style="background-color: rgba(0, 0, 0, 0.05);">
            <div class="mapouter"><div class="gmap_canvas"><iframe width="301" height="217" id="gmap_canvas" src="https://maps.google.com/maps?q=De%20Louwstraat,%20Hoogschaijksestraat%2031,%205374%20EC%20Schaijk&t=&z=17&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://123movies-to.org">123movies</a><br><style>.mapouter{position:relative;text-align:right;height:217px;width:301px;}</style><a href="https://www.embedgooglemap.net">embedgooglemap.net</a><style>.gmap_canvas {overflow:hidden;background:none!important;height:217px;width:301px;}</style></div></div>
      </div>
          <!-- Grid column -->
        </div>
        <!-- Grid row -->
      </div>
    </section>
    <!-- Section: Links  -->
  
    <!-- Copyright -->
    
    <!-- Copyright -->
  </footer>
  <!-- Footer -->
</main>
