<?php
function enqueue_my_custom_styles(){
    wp_enqueue_style( 'style.css', '', false);
}

add_action('wp_enqueue_scripts', 'enqueue_my_custom_styles');

?>