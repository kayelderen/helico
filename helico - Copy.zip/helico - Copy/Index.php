<?php get_header(); ?>
<main>

  <div class="container welkom">
    <div class="text-center">
        <h2 class="section-heading text-uppercase">Welkom bij Helico</h2>
        <h3 class="section-subheading text-muted">Ontwikkeling en verpakking.</h3>
    </div>
   
    
</div>
  
<section id="about" class="about">
  <div class="container">
    <div class="section-title">
      <h2 class="text-justify aboutustekst heliheader">Over ons en onze werkzaamheden</h2>
        </div>
        <div class="row">
          <div class="col-lg-6 order-1 order-lg-2"> 
            <img src="http://localhost/localwp/wp-content/uploads/2022/08/lab-500.png" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
            <h4 class="blue-header">Wij zijn een team dat bij elkaar 37 jaar ervaring heeft op het gebied van productontwikkeling, kwaliteitszorg en productiebegeleiding.</h4>
            <p class="fst-italic"> Onze werkzaamheden zijn onder meer:</p>
            <ul><li><i class="bi bi-check-circled"></i> <p class="lead fw-normal text-white-50 mb-4">Ontwikkeling van reinigings-, onderhouds-, en cosmetische produkten voor de zakelijke markt.</p></li>
              <li><i class="bi bi-check-circled"></i> <p class="lead fw-normal text-white-50 mb-4">Afgevulde producten, verpakt of geseald, kunnen wij voor u distribueren, maar ook (tijdelijk) voor u opslaan.</p></li>
              <li><i class="bi bi-check-circled"></i><p class="lead fw-normal text-white-50 mb-4"> Etiketten in verschillende mogelijke materialen, afmetingen en kwaliteiten.</p></li></ul><p>
                Wij beschikken hiervoor over een eigen laboratorium en uiteraard de nodige kennis en ruime ervaring.</p>
                </div>
              </div>
            </div>
</section>

<?php get_footer(); ?>